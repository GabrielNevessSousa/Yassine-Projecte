import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmar-producto',
  templateUrl: './confirmar-producto.component.html',
  styleUrls: ['./confirmar-producto.component.css']
})
export class ConfirmarProductoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
