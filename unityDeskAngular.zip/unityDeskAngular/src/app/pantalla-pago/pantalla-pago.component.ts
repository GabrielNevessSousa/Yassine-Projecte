import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pantalla-pago',
  templateUrl: './pantalla-pago.component.html',
  styleUrls: ['./pantalla-pago.component.css']
})
export class PantallaPagoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
