import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pantalla-usuari',
  templateUrl: './pantalla-usuari.component.html',
  styleUrls: ['./pantalla-usuari.component.css']
})
export class PantallaUsuariComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
