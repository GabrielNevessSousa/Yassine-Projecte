import { Component } from '@angular/core';

@Component({
  selector: 'app-pantalla-usuari',
  templateUrl: './pantalla-usuari.component.html',
  styleUrls: ['./pantalla-usuari.component.css']
})
export class PantallaUsuariComponent{

  nombreUsuario: string = "MI USUARIO";
  nuevoNombreUsuario: string = "";

  constructor() { }

  editarNombreUsuario() {
    this.nombreUsuario = this.nuevoNombreUsuario;
  }

}
