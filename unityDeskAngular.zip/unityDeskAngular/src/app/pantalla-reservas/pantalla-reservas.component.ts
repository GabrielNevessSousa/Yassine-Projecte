import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pantalla-reservas',
  templateUrl: './pantalla-reservas.component.html',
  styleUrls: ['./pantalla-reservas.component.css']
})
export class PantallaReservasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
